import java.util.*;

public class AIAgent{
    Random rand;

    public AIAgent(){
        rand = new Random();
    }

/*
  The method randomMove takes as input a stack of potential moves that the AI agent
  can make. The agent uses a random number generator to randomly select a move from
  the inputted Stack and returns this to the calling agent.
*/

    public Move randomMove(Stack possibilities){

        int moveID = rand.nextInt(possibilities.size());
        System.out.println("Agent randomly selected move : "+moveID);
        for(int i=1;i < (possibilities.size()-(moveID));i++){
            possibilities.pop();
        }
        Move selectedMove = (Move)possibilities.pop();
        return selectedMove;
    }

    /*

        AI does not care once a move has been made, meaning the AI can take a piece but end up leaving itself vulnerable
        e.g Uses queen to take pawn but leaves queen in a spot where it could be taken by another pawn

        Piece Values :
        Pawn 1
        Knight / Bishop 3
        Rook 5
        Queen 9
        King Game

        This strategy gets all possible moves like random agent. Use function to work out what piece to take using the above values.

     */

    public Move nextBestMove(Stack possibilities){


            int moveID = rand.nextInt(possibilities.size());
        System.out.println("Agent chose to move : "+moveID);
        for(int i=1;i < (possibilities.size()-(moveID));i++){
            possibilities.pop();
        }
        Move selectedMove = new Move();
        return selectedMove;
    }

    /*

        Random Moves --> get all possible moves for white
                     --> select a move

                     Next Best Move --> get all possible moves for white
                                    --> create function based on current move that checks value of pieces
                                    --> loop through the stack of moves and take the best available piece

                                    Two Levels Deep --> get all possible moves for white (stack)
                                                    then get all possible moves for the player
                                                    --> get all possible moves for black after the board changes for each movement
                                                    --> rank these accordingly using utility function
                                                    --> the agent makes a move based on the best move for it and which is the worse outcome for black

     */


    public Move twoLevelsDeep(Stack possibilities){
        Move selectedMove = new Move();
        return selectedMove;
    }
}