import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.util.*;
import javax.swing.border.Border;


/*
	This class can be used as a starting point for creating your Chess game project. The only piece that 
	has been coded is a white pawn...a lot done, more to do!
*/
 
public class ChessProject extends JFrame implements MouseListener, MouseMotionListener {
	JFrame frame = new JFrame("Checkmate");
    JLayeredPane layeredPane;
    JPanel chessBoard;
    JLabel chessPiece;
    int xAdjustment;
    int yAdjustment;
	int startX;
	int startY;
	int initialX;
	int initialY;
	JPanel panels;
	JLabel pieces;
	Boolean whiteTurn;
	AIAgent aiPlayer;
	int turnCounter;
	Boolean agentwins;
	Stack temporary;
	static int AIDifficulty;


    public ChessProject(){
        Dimension boardSize = new Dimension(600, 600);

        //  Use a Layered Pane for this application
        layeredPane = new JLayeredPane();
        getContentPane().add(layeredPane);
        layeredPane.setPreferredSize(boardSize);
        layeredPane.addMouseListener(this);
        layeredPane.addMouseMotionListener(this);

        //Add a chess board to the Layered Pane
        chessBoard = new JPanel();
        layeredPane.add(chessBoard, JLayeredPane.DEFAULT_LAYER);
        chessBoard.setLayout( new GridLayout(8, 8) );
        chessBoard.setPreferredSize( boardSize );
        chessBoard.setBounds(0, 0, boardSize.width, boardSize.height);

        for (int i = 0; i < 64; i++) {
            JPanel square = new JPanel( new BorderLayout() );
            chessBoard.add( square );

            int row = (i / 8) % 2;
            if (row == 0)
                square.setBackground( i % 2 == 0 ? Color.white : Color.gray );
            else
                square.setBackground( i % 2 == 0 ? Color.gray : Color.white );
        }

        // Setting up the Initial Chess board.
		for(int i=8;i < 16; i++){
       		pieces = new JLabel( new ImageIcon("WhitePawn.png") );
			panels = (JPanel)chessBoard.getComponent(i);
	        panels.add(pieces);
		}
		pieces = new JLabel( new ImageIcon("WhiteRook.png") );
		panels = (JPanel)chessBoard.getComponent(0);
	    panels.add(pieces);
		pieces = new JLabel( new ImageIcon("WhiteKnight.png") );
		panels = (JPanel)chessBoard.getComponent(1);
	    panels.add(pieces);
		pieces = new JLabel( new ImageIcon("WhiteKnight.png") );
		panels = (JPanel)chessBoard.getComponent(6);
	    panels.add(pieces);
		pieces = new JLabel( new ImageIcon("WhiteBishop.png") );
		panels = (JPanel)chessBoard.getComponent(2);
	    panels.add(pieces);
		pieces = new JLabel( new ImageIcon("WhiteBishop.png") );
		panels = (JPanel)chessBoard.getComponent(5);
	    panels.add(pieces);
		pieces = new JLabel( new ImageIcon("WhiteKing.png") );
		panels = (JPanel)chessBoard.getComponent(3);
	    panels.add(pieces);
		pieces = new JLabel( new ImageIcon("WhiteQueen.png") );
		panels = (JPanel)chessBoard.getComponent(4);
	    panels.add(pieces);
		pieces = new JLabel( new ImageIcon("WhiteRook.png") );
		panels = (JPanel)chessBoard.getComponent(7);
	    panels.add(pieces);
		for(int i=48;i < 56; i++){
       		pieces = new JLabel( new ImageIcon("BlackPawn.png") );
			panels = (JPanel)chessBoard.getComponent(i);
	        panels.add(pieces);
		}
		pieces = new JLabel( new ImageIcon("BlackRook.png") );
		panels = (JPanel)chessBoard.getComponent(56);
	    panels.add(pieces);
		pieces = new JLabel( new ImageIcon("BlackKnight.png") );
		panels = (JPanel)chessBoard.getComponent(57);
	    panels.add(pieces);
		pieces = new JLabel( new ImageIcon("BlackKnight.png") );
		panels = (JPanel)chessBoard.getComponent(62);
	    panels.add(pieces);
		pieces = new JLabel( new ImageIcon("BlackBishop.png") );
		panels = (JPanel)chessBoard.getComponent(58);
	    panels.add(pieces);
		pieces = new JLabel( new ImageIcon("BlackBishop.png") );
		panels = (JPanel)chessBoard.getComponent(61);
	    panels.add(pieces);
		pieces = new JLabel( new ImageIcon("BlackKing.png") );
		panels = (JPanel)chessBoard.getComponent(59);
	    panels.add(pieces);
		pieces = new JLabel( new ImageIcon("BlackQueen.png") );
		panels = (JPanel)chessBoard.getComponent(60);
	    panels.add(pieces);
		pieces = new JLabel( new ImageIcon("BlackRook.png") );
		panels = (JPanel)chessBoard.getComponent(63);
	    panels.add(pieces);

		turnCounter = 0;
	    whiteTurn = true;
	    aiPlayer = new AIAgent();
	    agentwins = false;
	    temporary = new Stack();

    }

	/*
		This method checks if there is a piece present on a particular square.
	*/

	private Boolean piecePresent(int x, int y){
		Component c = chessBoard.findComponentAt(x, y);
		if(c instanceof JPanel){
			return false;
		}
		else{
			return true;
		}
	}

	/*
		This is a method to check if a piece is a Black piece. White is Attacking Black
	*/
	private Boolean checkWhiteOpponent(int newX, int newY){
		// declare opponent variable
		Boolean opponent;
		// find where the piece is on the board
		Component c1 = chessBoard.findComponentAt(newX, newY);
		// wait for the piece to land on it
		JLabel awaitingPiece = (JLabel)c1;
		String tmp1 = awaitingPiece.getIcon().toString();
		// if the piece it is landing on is black
		if(((tmp1.contains("Black")))){
			// it is white's opponent
			opponent = true;
			if(tmp1.contains("BlackKing")) {
				JOptionPane.showMessageDialog(frame, "White has checkmated Black!");
				System.exit(0);
			}
		}
		// if the piece it is landing on is white
		else{
			// it is white's own piece
			opponent = false;
		}
		return opponent;
	}

	// check if a piece is a white piece Black is attacking White

	private Boolean checkBlackOpponent(int newX, int newY){
		// declare opponent variable
		Boolean opponent;
		// find where the piece is on the board
		Component c1 = chessBoard.findComponentAt(newX, newY);
		// wait for a piece to land on it
		JLabel awaitingPiece = (JLabel)c1;
		String tmp1 = awaitingPiece.getIcon().toString();
		// if the piece it is landing on is white
		if(((tmp1.contains("White")))){
			// it is black's opponent
			opponent = true;
			if(tmp1.contains("WhiteKing")) {
				JOptionPane.showMessageDialog(frame, "Black has checkmated White!");
				System.exit(0);
			}
		}
		// if the piece it is landing on it black
		else{
			// it is black's own piece
			opponent = false;
		}
		return opponent;
	}

	// function for checking the value of each piece, used for best next move strategy
	public int checkPieceValue(int newX, int newY){
		Component c2 = chessBoard.findComponentAt(newX, newY);
		JLabel awaitingPiece = (JLabel)c2;
		// piece score is used to define the weight/value of each piece where the ai can determine which is the highest for capture
		int pieceScore = 0;
		String tmp2 = awaitingPiece.getIcon().toString();
		if(((tmp2.contains("Pawn")))){
			pieceScore = 1;
		}
		else if(((tmp2.contains("Knight")))){
			pieceScore = 3;
		}
		else if(((tmp2.contains("Bishop")))){
			pieceScore = 3;
		}
		else if(((tmp2.contains("Rook")))){
			pieceScore = 5;
		}
		else if(((tmp2.contains("Queen")))){
			pieceScore = 9;
		}
		else if(((tmp2.contains("King")))){
			pieceScore = 20;
		}
		return pieceScore;
	}

	// used for finding what piece is on a square/surrounding squares
	private String getPieceName(int x, int y){
		//find where the piece is on the board
		Component c1 = chessBoard.findComponentAt(x, y);
		// if there is no piece there
		if(c1 instanceof JPanel){
			return "empty";
		}
		// if there is a piece there
		else if(c1 instanceof JLabel){
			// identify piece and convert icon to string for piece name
			JLabel awaitingPiece = (JLabel)c1;
			String tmp1 = awaitingPiece.getIcon().toString();
			return tmp1;
		}
		else{
			return "empty";
		}
	}

	// used for check
	private Boolean checkSurroundingSquares(Square s){
		Boolean possible = false;
		int x = s.getXC()*75;
		int y = s.getYC()*75;
		if(!((getPieceName((x+75), y).contains("BlackKing"))||(getPieceName((x-75), y).contains("BlackKing"))||(getPieceName(x,(y+75)).contains("BlackKing"))||(getPieceName((x), (y-75)).contains("BlackKing"))||(getPieceName((x+75),(y+75)).contains("BlackKing"))||(getPieceName((x-75),(y+75)).contains("BlackKing"))||(getPieceName((x+75),(y-75)).contains("BlackKing"))||(getPieceName((x-75), (y-75)).contains("BlackKing")))){
			possible = true;
		}
		return possible;
	}

	/*
        Method to colour a stack of Squares
*/
	private void colorSquares(Stack squares){
		Border greenBorder = BorderFactory.createLineBorder(Color.GREEN, 3);
		while(!squares.empty()){
			Square s = (Square)squares.pop();
			int location = s.getXC() + ((s.getYC())*8);
			JPanel panel = (JPanel)chessBoard.getComponent(location);
			panel.setBorder(greenBorder);
		}
	}

	/*
    Method to get the landing square of a bunch of moves...
*/
	private void getLandingSquares(Stack found){
		Move tmp;
		Square landing;
		Stack squares = new Stack();
		while(!found.empty()){
			tmp = (Move)found.pop();
			landing = (Square)tmp.getLanding();
			squares.push(landing);
		}
		colorSquares(squares);
	}

	/*
  Method to find all the White Pieces.
*/
	private Stack findWhitePieces(){
		Stack squares = new Stack();
		String icon;
		int x;
		int y;
		String pieceName;
		for(int i=0;i < 600;i+=75){
			for(int j=0;j < 600;j+=75){
				y = i/75;
				x=j/75;
				Component tmp = chessBoard.findComponentAt(j, i);
				if(tmp instanceof JLabel){
					chessPiece = (JLabel)tmp;
					icon = chessPiece.getIcon().toString();
					pieceName = icon.substring(0, (icon.length()-4));
					if(pieceName.contains("White")){
						Square stmp = new Square(x, y, pieceName);
						squares.push(stmp);
					}
				}
			}
		}
		return squares;
	}

	private Stack findBlackPieces(){
		Stack squares = new Stack();
		String icon;
		int x;
		int y;
		String pieceName;
		for(int i=0;i < 600;i+=75){
			for(int j=0;j < 600;j+=75){
				y = i/75;
				x=j/75;
				Component tmp = chessBoard.findComponentAt(j, i);
				if(tmp instanceof JLabel){
					chessPiece = (JLabel)tmp;
					icon = chessPiece.getIcon().toString();
					pieceName = icon.substring(0, (icon.length()-4));
					if(pieceName.contains("Black")){
						Square stmp = new Square(x, y, pieceName);
						squares.push(stmp);
					}
				}
			}
		}
		return squares;
	}

	// reset the borders of squares after a move has been made so that new ones can be highlighted
	private void resetBorders(){
		Border empty = BorderFactory.createEmptyBorder();
		for(int i=0;i < 64;i++){
			JPanel tmppanel = (JPanel)chessBoard.getComponent(i);
			tmppanel.setBorder(empty);
		}
	}

	/*
      The method printStack takes in a Stack of Moves and prints out all possible moves.
    */
	private void printStack(Stack input){
		Move m;
		Square s, l;
		while(!input.empty()){
			m = (Move)input.pop();
			s = (Square)m.getStart();
			l = (Square)m.getLanding();
			System.out.println("The possible move that was found is : ("+s.getXC()+" , "+s.getYC()+"), landing at ("+l.getXC()+" , "+l.getYC()+")");
		}
	}

	private Stack<Move> getKnightMoves(int x, int y, String piece){
		Square startingSquare = new Square(x, y, piece);
		Stack<Square> squares = new Stack();
		Stack<Move> attackingMove = new Stack();
		// Square to handle where the piece can land
		Square s = new Square(x+1, y+2, piece);
		// push the square into the stack
		squares.push(s);
		Square s1 = new Square(x+1, y-2, piece);
		squares.push(s1);
		Square s2 = new Square(x-1, y+2, piece);
		squares.push(s2);
		Square s3 = new Square(x-1, y-2, piece);
		squares.push(s3);
		Square s4 = new Square(x+2, y+1, piece);
		squares.push(s4);
		Square s5 = new Square(x+2, y-1, piece);
		squares.push(s5);
		Square s6 = new Square(x-2, y+1, piece);
		squares.push(s6);
		Square s7 = new Square(x-2, y-1, piece);
		squares.push(s7);

		// loop through all the ways the knight can move
		for(int i=0;i < 8;i++){
			// populate the stack of squares
			Square tmp = squares.pop();
			// moves are created by having the startingsquare and landingsquares
			Move tmpMove = new Move(startingSquare, tmp);
			// so long as the piece is not trying to move off the board
			if((tmp.getXC() < 0)||(tmp.getXC() > 7)||(tmp.getYC() < 0)||(tmp.getYC() > 7)){

			}
			// if there is a piece present, check if it is an opponent piece and get the value of the piece if it can capture it
			else if(piecePresent(((tmp.getXC()*75)+20), (((tmp.getYC()*75)+20)))){
				if(piece.contains("White")){
					if(checkWhiteOpponent(((tmp.getXC()*75)+20), ((tmp.getYC()*75)+20))){
						tmpMove.score = checkPieceValue(((tmp.getXC()*75)+20), ((tmp.getYC()*75)+20));
						attackingMove.push(tmpMove);
					}
				}
			}
			// the piece is free to move to the square
			else{
				attackingMove.push(tmpMove);
			}
		}
		return attackingMove;
	}

	// used for handling the white pawn's attack moves
	private Stack<Move> getWhitePawnMoves(int x, int y, String piece){
		// stack for all attacking moves the white pawn can make
		Stack<Move> attacking = new Stack();

		Square startingSquare = new Square(x,y, piece);
		Move validM1, validM2, validM3, validM4;
		// Square to handle where the piece has landed
		Square s1 = new Square(x, y+1 , piece);
		// determines a move is valid by getting the startingSquare of the piece and where it is landing
		validM1 = new Move(startingSquare, s1);
		Square s2 = new Square(x, y + 2, piece);
		validM2 = new Move(startingSquare, s2);
		Square s3 = new Square(x+1, y+1, piece);
		validM3 = new Move(startingSquare, s3);
		Square s4 = new Square(x-1, y+1, piece);
		validM4 = new Move(startingSquare, s4);


		// if the pawn is just moving normally
		// so long as the piece is not trying to move off the board
		if((validM1.landing.getXC() >= 0 && (validM1.landing.getXC() <= 7) && (validM1.landing.getYC() >= 0) && (validM1.landing.getYC() <= 7))){
			// only valid move if there is no piece present
			if(!piecePresent(((validM1.landing.getXC()*75)+20), (((validM1.landing.getYC()*75)+20)))){
				attacking.push(validM1);
			}
		}
		// if it is the pawns starting location, it can move one or two squares
		if(y == 1) {
			if ((validM2.landing.getXC() >= 0 && (validM2.landing.getXC() <= 7) && (validM2.landing.getYC() >= 0) && (validM2.landing.getYC() <= 7))) {
				// only valid move if there is no piece present
				if (!piecePresent(((validM2.landing.getXC() * 75) + 20), (((validM2.landing.getYC() * 75) + 20)))) {
					attacking.push(validM2);
				}
			}
		}
		// Check to see if there is an opponent to add attacking squares
		if((validM3.landing.getXC() >= 0 && (validM3.landing.getXC() <= 7) && (validM3.landing.getYC() >= 0) && (validM3.landing.getYC() <= 7))) {
			// if there is a piece present, check if it is an opponent and get the value of the piece it can capture
			if (piecePresent(((s3.getXC() * 75) + 20), (((s3.getYC() * 75) + 20)))) {
				if (checkWhiteOpponent(((s3.getXC() * 75) + 20), (((s3.getYC() * 75) + 20)))) {
					validM3.score = checkPieceValue(((s3.getXC()*75)+20), ((s3.getYC()*75)+20));
					attacking.push(validM3);
				} else {
					System.out.println("It is white's own piece");
				}
			}
		}
		if((validM4.landing.getXC() >= 0 && (validM4.landing.getXC() <= 7) && (validM4.landing.getYC() >= 0) && (validM4.landing.getYC() <= 7))) {
			if (piecePresent(((s4.getXC() * 75) + 20), (((s4.getYC() * 75) + 20)))) {
				if (checkWhiteOpponent(((s4.getXC() * 75) + 20), (((s4.getYC() * 75) + 20)))) {
					validM4.score = checkPieceValue(((s4.getXC()*75)+20), ((s4.getYC()*75)+20));
					attacking.push(validM4);
				} else {
					System.out.println("It is white's own piece");
				}
			}
		}
		return attacking;
	}

	// used for handling the black pawn's attack moves
	private Stack getBlackPawnMoves(int x, int y, String piece){
		// stack for handling the piece's moves
		Stack moves = new Stack();
		// stack for handling the piece's attack moves
		Stack attacking = new Stack();
		Square s = new Square(x-1, y-1);
		moves.push(s);
		Square s1 = new Square(x+1, y-1);
		moves.push(s1);
		// loop through all the moves
		for(int i=0; i < 2; i++){
			Square tmp =(Square)moves.pop();
			// stop the loop if it tries to fall off the board
			if((tmp.getXC() < 0 || (tmp.getXC() > 7) || (tmp.getYC() <0) || (tmp.getYC() > 7))){
				break;
			}
			// if it finds a piece
			else if(piecePresent(((tmp.getXC()*75)+20), (((tmp.getYC()*75)+20)))){
				// if it finds a white piece
				if(piece.contains("White")){
					if(checkBlackOpponent(((tmp.getXC()*75)+20), (((tmp.getYC()*75)+20)))){
						// add the attack move to the stack
						attacking.push(tmp);
					}
					else{
						System.out.println("It is black's own piece");
					}
				}
			}
			else{
				attacking.push(tmp);
			}
		}
		Stack tmp = attacking;
		return attacking;
	}

	// used for handling the king's moves
	private Stack<Move> getKingMoves(int x, int y, String piece){
		// find the coordinates of the kings starting location
		Square startingSquare = new Square(x, y, piece);
		// stack for holding all moves the piece can make so long as they are valid
		Stack<Move> moves = new Stack();
		// Moves for each of the directions
		Move validM, validM2, validM3, validM4;
		// handles the directions the piece can move
		int tmpx1 = x+1;
		int tmpx2 = x-1;
		int tmpy1 = y+1;
		int tmpy2 = y-1;

/*
  If we consider the grid above, we can create three different columes to check.
    - if x increases by one square, using the variable tmpx1 (x+1)
    - if x decreases by one square, using the variable tmpx2 (x-1)
    - or if x stays the same.
*/
		if(!((tmpx1 > 7))){
    /*
      This is the first condition where we will be working with the column where x increases.
      If we consider x increasing, we need to make sure that we don't fall off the board, so we use
      a condition here to check that the new value of x (tmpx1) is not greater than 7.

      From the grid above we can see in this column that there are three possible squares for us to check in
      this column:
      - were y decreases, y-1
      - were y increases, y+1
      - or were y stays the same

      The first step is to construct three new Squares for each of these possibilities.
      As the unchanged y value is already a location on the board we don't need to check the location and can simply
      make a call to checkSurroundingSquares for this new Square.

      If checkSurroundingSquares returns a positive value we jump inside the condition below:
        - firstly we create a new Move, which takes the starting square and the landing square that we have just checked with
          checkSurroundingSquares.
        - Next we need to figure out if there is a piece present on the square and if so make sure
          that the piece is an opponents piece.
        - Once we make sure that we are either moving to an empty square or we are taking our opponents piece we can push this
          possible move onto our stack of possible moves called "moves".

      This process is followed again for the other temporary squares created.

      After we check for all possoble squares on this column, we repeat the process for the other columns as identified above
      in the grid.
    */
			Square tmp = new Square(tmpx1, y, piece);
			Square tmp1 = new Square(tmpx1, tmpy1, piece);
			Square tmp2 = new Square(tmpx1, tmpy2, piece);
			if(checkSurroundingSquares(tmp)){
				validM = new Move(startingSquare, tmp);
				if(!piecePresent(((tmp.getXC()*75)+20), (((tmp.getYC()*75)+20)))){
					moves.push(validM);
				}
				else{
					if(checkWhiteOpponent(((tmp.getXC()*75)+20), (((tmp.getYC()*75)+20)))){
						validM.score = checkPieceValue(((tmp.getXC()*75)+20), ((tmp.getYC()*75)+20));
						moves.push(validM);
					}
				}
			}
			if(!(tmpy1 > 7)){
				if(checkSurroundingSquares(tmp1)){
					validM2 = new Move(startingSquare, tmp1);
					if(!piecePresent(((tmp1.getXC()*75)+20), (((tmp1.getYC()*75)+20)))){
						moves.push(validM2);
					}
					else{
						if(checkWhiteOpponent(((tmp1.getXC()*75)+20), (((tmp1.getYC()*75)+20)))){
							validM2.score = checkPieceValue(((tmp1.getXC()*75)+20), ((tmp1.getYC()*75)+20));
							moves.push(validM2);
						}
					}
				}
			}
			if(!(tmpy2 < 0)){
				if(checkSurroundingSquares(tmp2)){
					validM3 = new Move(startingSquare, tmp2);
					if(!piecePresent(((tmp2.getXC()*75)+20), (((tmp2.getYC()*75)+20)))){
						moves.push(validM3);
					}
					else{
						System.out.println("The values that we are going to be looking at are : "+((tmp2.getXC()*75)+20)+" and the y value is : "+((tmp2.getYC()*75)+20));
						if(checkWhiteOpponent(((tmp2.getXC()*75)+20), (((tmp2.getYC()*75)+20)))){
							validM3.score = checkPieceValue(((tmp2.getXC()*75)+20), ((tmp2.getYC()*75)+20));
							moves.push(validM3);
						}
					}
				}
			}
		}
		if(!((tmpx2 < 0))){
			Square tmp3 = new Square(tmpx2, y, piece);
			Square tmp4 = new Square(tmpx2, tmpy1, piece);
			Square tmp5 = new Square(tmpx2, tmpy2, piece);
			if(checkSurroundingSquares(tmp3)){
				validM = new Move(startingSquare, tmp3);
				if(!piecePresent(((tmp3.getXC()*75)+20), (((tmp3.getYC()*75)+20)))){
					moves.push(validM);
				}
				else{
					if(checkWhiteOpponent(((tmp3.getXC()*75)+20), (((tmp3.getYC()*75)+20)))){
						validM.score = checkPieceValue(((tmp3.getXC()*75)+20), ((tmp3.getYC()*75)+20));
						moves.push(validM);
					}
				}
			}
			if(!(tmpy1 > 7)){
				if(checkSurroundingSquares(tmp4)){
					validM2 = new Move(startingSquare, tmp4);
					if(!piecePresent(((tmp4.getXC()*75)+20), (((tmp4.getYC()*75)+20)))){
						moves.push(validM2);
					}
					else{
						if(checkWhiteOpponent(((tmp4.getXC()*75)+20), (((tmp4.getYC()*75)+20)))){
							validM2.score = checkPieceValue(((tmp4.getXC()*75)+20), ((tmp4.getYC()*75)+20));
							moves.push(validM2);
						}
					}
				}
			}
			if(!(tmpy2 < 0)){
				if(checkSurroundingSquares(tmp5)){
					validM3 = new Move(startingSquare, tmp5);
					if(!piecePresent(((tmp5.getXC()*75)+20), (((tmp5.getYC()*75)+20)))){
						moves.push(validM3);
					}
					else{
						if(checkWhiteOpponent(((tmp5.getXC()*75)+20), (((tmp5.getYC()*75)+20)))){
							validM3.score = checkPieceValue(((tmp5.getXC()*75)+20), ((tmp5.getYC()*75)+20));
							moves.push(validM3);
						}
					}
				}
			}
		}
		Square tmp7 = new Square(x, tmpy1, piece);
		Square tmp8 = new Square(x, tmpy2, piece);
		if(!(tmpy1 > 7)){
			if(checkSurroundingSquares(tmp7)){
				validM2 = new Move(startingSquare, tmp7);
				if(!piecePresent(((tmp7.getXC()*75)+20), (((tmp7.getYC()*75)+20)))){
					moves.push(validM2);
				}
				else{
					if(checkWhiteOpponent(((tmp7.getXC()*75)+20), (((tmp7.getYC()*75)+20)))){
						validM2.score = checkPieceValue(((tmp7.getXC()*75)+20), ((tmp7.getYC()*75)+20));
						moves.push(validM2);
					}
				}
			}
		}
		if(!(tmpy2 < 0)){
			if(checkSurroundingSquares(tmp8)){
				validM3 = new Move(startingSquare, tmp8);
				if(!piecePresent(((tmp8.getXC()*75)+20), (((tmp8.getYC()*75)+20)))){
					moves.push(validM3);
				}
				else{
					if(checkWhiteOpponent(((tmp8.getXC()*75)+20), (((tmp8.getYC()*75)+20)))){
						validM3.score = checkPieceValue(((tmp8.getXC()*75)+20), ((tmp8.getYC()*75)+20));
						moves.push(validM3);
					}
				}
			}
		}
		return moves;
	}

	private Stack<Move> getRookMoves(int x, int y, String piece){
		Square startingSquare = new Square(x, y, piece);
		Stack moves = new Stack();
		Move validM, validM2, validM3, validM4;
  /*
    There are four possible directions that the Rook can move to:
      - the x value is increasing
      - the x value is decreasing
      - the y value is increasing
      - the y value is decreasing

    Each of these movements should be catered for. The loop guard is set to incriment up to the maximun number of squares.
    On each iteration of the first loop we are adding the value of i to the current x coordinate.
    We make sure that the new potential square is going to be on the board and if it is we create a new square and a new potential
    move (originating square, new square).If there are no pieces present on the potential square we simply add it to the Stack
    of potential moves.
    If there is a piece on the square we need to check if its an opponent piece. If it is an opponent piece its a valid move, but we
    must break out of the loop using the Java break keyword as we can't jump over the piece and search for squares. If its not
    an opponent piece we simply break out of the loop.

    This cycle needs to happen four times for each of the possible directions of the Rook.
  */
		for(int i=1;i < 8;i++){
			int tmpx = x+i;
			int tmpy = y;
			if(!(tmpx > 7 || tmpx < 0)){
				Square tmp = new Square(tmpx, tmpy, piece);
				validM = new Move(startingSquare, tmp);
				if(!piecePresent(((tmp.getXC()*75)+20), (((tmp.getYC()*75)+20)))){
					moves.push(validM);
				}
				else{
					if(checkWhiteOpponent(((tmp.getXC()*75)+20), ((tmp.getYC()*75)+20))){
						validM.score = checkPieceValue(((tmp.getXC()*75)+20), ((tmp.getYC()*75)+20));
						moves.push(validM);
						break;
					}
					else{
						break;
					}
				}
			}
		}//end of the loop with x increasing and Y doing nothing...
		for(int j=1;j < 8;j++){
			int tmpx1 = x-j;
			int tmpy1 = y;
			if(!(tmpx1 > 7 || tmpx1 < 0)){
				Square tmp2 = new Square(tmpx1, tmpy1, piece);
				validM2 = new Move(startingSquare, tmp2);
				if(!piecePresent(((tmp2.getXC()*75)+20), (((tmp2.getYC()*75)+20)))){
					moves.push(validM2);
				}
				else{
					if(checkWhiteOpponent(((tmp2.getXC()*75)+20), ((tmp2.getYC()*75)+20))){
						validM2.score = checkPieceValue(((tmp2.getXC()*75)+20), ((tmp2.getYC()*75)+20));
						moves.push(validM2);
						break;
					}
					else{
						break;
					}
				}
			}
		}//end of the loop with x decreasing and y doing nothing...
		for(int k=1;k < 8;k++){
			int tmpx3 = x;
			int tmpy3 = y+k;
			if(!(tmpy3 > 7 || tmpy3 < 0)){
				Square tmp3 = new Square(tmpx3, tmpy3, piece);
				validM3 = new Move(startingSquare, tmp3);
				if(!piecePresent(((tmp3.getXC()*75)+20), (((tmp3.getYC()*75)+20)))){
					moves.push(validM3);
				}
				else{
					if(checkWhiteOpponent(((tmp3.getXC()*75)+20), ((tmp3.getYC()*75)+20))){
						validM3.score = checkPieceValue(((tmp3.getXC()*75)+20), ((tmp3.getYC()*75)+20));
						moves.push(validM3);
						break;
					}
					else{
						break;
					}
				}
			}
		}//end of the loop with y increasing and x doing nothing...
		for(int l=1;l < 8;l++){
			int tmpx4 = x;
			int tmpy4 = y-l;
			if(!(tmpy4 > 7 || tmpy4 < 0)){
				Square tmp4 = new Square(tmpx4, tmpy4, piece);
				validM4 = new Move(startingSquare, tmp4);
				if(!piecePresent(((tmp4.getXC()*75)+20), (((tmp4.getYC()*75)+20)))){
					moves.push(validM4);
				}
				else{
					if(checkWhiteOpponent(((tmp4.getXC()*75)+20), ((tmp4.getYC()*75)+20))){
						validM4.score = checkPieceValue(((tmp4.getXC()*75)+20), ((tmp4.getYC()*75)+20));
						moves.push(validM4);
						break;
					}
					else{
						break;
					}
				}
			}
		}//end of the loop with y decreasing and x doing nothing...
		return moves;
	}

	// returning a stack of moves
	private Stack<Move> getBishopMoves(int x, int y, String piece){
		Square startingSquare = new Square(x, y, piece);
		Stack<Move> moves = new Stack();
		Move validM, validM2, validM3, validM4;
  /*
    The Bishop can move along any diagonal until it hits an enemy piece or its own piece
    it cannot jump over its own piece. We need to use four different loops to go through the possible movements
    to identify possible squares to move to. The temporary squares, i.e. the values of x and y must change by the
    same amount on each iteration of each of the loops.

    If the new values of x and y are on the board, we create a new square and a new move (from the original square to the new
    square). We then check if there is a piece present on the new square:
    - if not we add the move as a possible new move
    - if there is a piece we make sure that we can capture our opponents piece and we cannot take our own piece
      and then we break out of the loop

    This process is repeated for each of the other three possible diagonals that the Bishop can travel along.

  */
		// moving to the north east
		for(int i=1;i < 8;i++){
			int tmpx = x+i;
			int tmpy = y+i;
			if(!(tmpx > 7 || tmpx < 0 || tmpy > 7 || tmpy < 0)){
				Square tmp = new Square(tmpx, tmpy, piece);
				validM = new Move(startingSquare, tmp);
				if(!piecePresent(((tmp.getXC()*75)+20), (((tmp.getYC()*75)+20)))){
					moves.push(validM);
				}
				else{
					if(checkWhiteOpponent(((tmp.getXC()*75)+20), ((tmp.getYC()*75)+20))){
						validM.score = checkPieceValue(((tmp.getXC()*75)+20), ((tmp.getYC()*75)+20));
						moves.push(validM);
						break;
					}
					else{
						break;
					}
				}
			}
		} // end of the first for Loop
		// moving to the south east
		for(int k=1;k < 8;k++){
			int tmpk = x+k;
			int tmpy2 = y-k;
			if(!(tmpk > 7 || tmpk < 0 || tmpy2 > 7 || tmpy2 < 0)){
				Square tmpK1 = new Square(tmpk, tmpy2, piece);
				validM2 = new Move(startingSquare, tmpK1);
				if(!piecePresent(((tmpK1.getXC()*75)+20), (((tmpK1.getYC()*75)+20)))){
					moves.push(validM2);
				}
				else{
					if(checkWhiteOpponent(((tmpK1.getXC()*75)+20), ((tmpK1.getYC()*75)+20))){
						validM2.score = checkPieceValue(((tmpK1.getXC()*75)+20), ((tmpK1.getYC()*75)+20));
						moves.push(validM2);
						break;
					}
					else{
						break;
					}
				}
			}
		} //end of second loop.
		// moving to the north west
		for(int l=1;l < 8;l++){
			int tmpL2 = x-l;
			int tmpy3 = y+l;
			if(!(tmpL2 > 7 || tmpL2 < 0 || tmpy3 > 7 || tmpy3 < 0)){
				Square tmpLMov2 = new Square(tmpL2, tmpy3, piece);
				validM3 = new Move(startingSquare, tmpLMov2);
				if(!piecePresent(((tmpLMov2.getXC()*75)+20), (((tmpLMov2.getYC()*75)+20)))){
					moves.push(validM3);
				}
				else{
					if(checkWhiteOpponent(((tmpLMov2.getXC()*75)+20), ((tmpLMov2.getYC()*75)+20))){
						validM3.score = checkPieceValue(((tmpLMov2.getXC()*75)+20), ((tmpLMov2.getYC()*75)+20));
						moves.push(validM3);
						break;
					}
					else{
						break;
					}
				}
			}
		}// end of the third loop
		// moving to the south east
		for(int n=1;n < 8;n++){
			int tmpN2 = x-n;
			int tmpy4 = y-n;
			if(!(tmpN2 > 7 || tmpN2 < 0 || tmpy4 > 7 || tmpy4 < 0)){
				Square tmpNmov2 = new Square(tmpN2, tmpy4, piece);
				validM4 = new Move(startingSquare, tmpNmov2);
				if(!piecePresent(((tmpNmov2.getXC()*75)+20), (((tmpNmov2.getYC()*75)+20)))){
					moves.push(validM4);
				}
				else{
					if(checkWhiteOpponent(((tmpNmov2.getXC()*75)+20), ((tmpNmov2.getYC()*75)+20))){
						validM4.score = checkPieceValue(((tmpNmov2.getXC()*75)+20), ((tmpNmov2.getYC()*75)+20));
						moves.push(validM4);
						break;
					}
					else{
						break;
					}
				}
			}
		}// end of the last loop
		return moves;
	}

	private Stack getQueenMoves(int x, int y, String piece){
		Stack completeMoves = new Stack();
		Stack tmpMoves = new Stack();
		Move tmp;
  /*
      The Queen is a pretty easy piece to figure out if you have completed the
      Bishop and the Rook movements. Either the Queen is going to move like a
      Bishop or its going to move like a Rook, so all we have to do is make a call to both of these
      methods.
  */
		tmpMoves = getRookMoves(x, y, piece);
		while(!tmpMoves.empty()){
			tmp = (Move)tmpMoves.pop();
			completeMoves.push(tmp);
		}
		tmpMoves = getBishopMoves(x, y, piece);
		while(!tmpMoves.empty()){
			tmp = (Move)tmpMoves.pop();
			completeMoves.push(tmp);
		}
		return completeMoves;
	}

	/* private Stack getWhiteAttackingSquares(Stack pieces){
		while(!pieces.empty()){
			Square s = (Square)pieces.pop();
			String tmpString = s.getName();
			if(tmpString.contains("Knight")){
				tempK = getKnightMoves(s.getXC(), s.getYC(), s.getName());
				while(!tempk.empty()){
					Square tempKnight = (Square)tmpK.pop();
					knight.push(tempKnight);
				}
			}
		}
	} */

	// function that handles the movements for the random ai agent
	private void makeAIMoveRandom(){
  /*
    When the AI Agent decides on a move, a red border shows the square from where the move started and the
    landing square of the move.
  */
		resetBorders();
		layeredPane.validate();
		layeredPane.repaint();
		Stack white = findWhitePieces();
		Stack completeMoves = new Stack();
		Move tmp;
		while(!white.empty()){
			Square startingSquare = (Square)white.pop();
			String tmpString = startingSquare.getName();
			Stack<Move> tmpMoves = new Stack();
			Stack temporary = new Stack();
    /*
        We need to identify all the possible moves that can be made by the AI Opponent
    */
			// get the AI to get the moves for the knight
			if(tmpString.contains("Knight")){
				tmpMoves = getKnightMoves(startingSquare.getXC(), startingSquare.getYC(), startingSquare.getName());
			}
			// get the AI to get the moves for the bishop
			else if(tmpString.contains("Bishop")){
				tmpMoves = getBishopMoves(startingSquare.getXC(), startingSquare.getYC(), startingSquare.getName());
			}
			// get the AI to get the moves for the pawn
			else if(tmpString.contains("Pawn")){
				tmpMoves = getWhitePawnMoves(startingSquare.getXC(), startingSquare.getYC(), startingSquare.getName());
			}
			// get the AI to get the moves for the rook
			else if(tmpString.contains("Rook")){
				tmpMoves = getRookMoves(startingSquare.getXC(), startingSquare.getYC(), startingSquare.getName());
			}
			// get the AI to get the moves for the queen
			else if(tmpString.contains("Queen")){
				tmpMoves = getQueenMoves(startingSquare.getXC(), startingSquare.getYC(), startingSquare.getName());
			}
			// get the AI to get the moves for the king
			else if(tmpString.contains("King")){
				tmpMoves = getKingMoves(startingSquare.getXC(), startingSquare.getYC(), startingSquare.getName());
			}

			// tmpMoves is a Stack of Squares
			while(!tmpMoves.empty()){
				completeMoves.push(tmpMoves.pop());
			}
		}
		temporary = (Stack)completeMoves.clone();
		getLandingSquares(temporary);
		printStack(temporary);
/*
So now we should have a copy of all the possible moves to make in our Stack called completeMoves
*/
		if(completeMoves.size() == 0){
/*
    In Chess if you cannot make a valid move but you are not in Check this state is referred to
    as a Stale Mate
*/
			JOptionPane.showMessageDialog(null, "Congratulations, you have placed the AI component in a Stale Mate Position");
			System.exit(0);

		}
		else{
  /*
    Okay, so we can make a move now. We have a stack of all possible moves and need to call the correct agent to select
    one of these moves. Lets print out the possible moves to the standard output to view what the options are for
    White. Later when you are finished the continuous assessment you don't need to have such information being printed
    out to the standard output.
  */
			System.out.println("=============================================================");
			Stack testing = new Stack();
			while(!completeMoves.empty()){
				Move tmpMove = (Move)completeMoves.pop();
				Square s1 = (Square)tmpMove.getStart();
				Square s2 = (Square)tmpMove.getLanding();
				System.out.println("The "+s1.getName()+" can move from ("+s1.getXC()+", "+s1.getYC()+") to the following square: ("+s2.getXC()+", "+s2.getYC()+")");
				testing.push(tmpMove);
			}
			System.out.println("=============================================================");
			// highlight landing square in red to show where the AI piece chose to move to
			Border redBorder = BorderFactory.createLineBorder(Color.RED, 3);
			// AI performs move based on criteria set in AIAgent
			Move selectedMove = aiPlayer.randomMove(testing);
			Square startingPoint = (Square)selectedMove.getStart();
			Square landingPoint = (Square)selectedMove.getLanding();
			int startX1 = (startingPoint.getXC()*75)+20;
			int startY1 = (startingPoint.getYC()*75)+20;
			int landingX1 = (landingPoint.getXC()*75)+20;
			int landingY1 = (landingPoint.getYC()*75)+20;
			System.out.println("-------- Move "+startingPoint.getName()+" ("+startingPoint.getXC()+", "+startingPoint.getYC()+") to ("+landingPoint.getXC()+", "+landingPoint.getYC()+")");

			Component c  = (JLabel)chessBoard.findComponentAt(startX1, startY1);
			Container parent = c.getParent();
			parent.remove(c);
			int panelID = (startingPoint.getYC() * 8)+startingPoint.getXC();
			panels = (JPanel)chessBoard.getComponent(panelID);
			panels.setBorder(redBorder);
			parent.validate();

			Component l = chessBoard.findComponentAt(landingX1, landingY1);
			if(l instanceof JLabel){
				Container parentlanding = l.getParent();
				JLabel awaitingName = (JLabel)l;
				// attempted to fix ai queening by  getting the moving piece and queening it once it lands on the end of the board but only if its the white pawn
				String agentPiece = startingPoint.getName();
				String agentCaptured = awaitingName.getIcon().toString();
				if(agentCaptured.contains("King")){
					agentwins = true;
				}
				if(agentPiece.contains("Pawn")){
					if(landingPoint.getYC() == 7){
						queenAWhitePawn(landingX1, c);
					}
				}
				parentlanding.remove(l);
				parentlanding.validate();
				pieces = new JLabel( new ImageIcon(startingPoint.getName()+".png") );
				int landingPanelID = (landingPoint.getYC()*8)+landingPoint.getXC();
				panels = (JPanel)chessBoard.getComponent(landingPanelID);
				panels.add(pieces);
				panels.setBorder(redBorder);
				layeredPane.validate();
				layeredPane.repaint();

				if(agentwins){
					JOptionPane.showMessageDialog(null, "The AI Agent has won!");
					System.exit(0);
				}
				// another method of attempting queening
				/*String tmpString = startingPoint.getName();
				if(startingPoint.getName().contains("Pawn") && landingPoint.getYC()==7){
					queenAWhitePawn(landingX1, l);
				}*/
			}
			else{
				pieces = new JLabel( new ImageIcon(startingPoint.getName()+".png") );
				int landingPanelID = (landingPoint.getYC()*8)+landingPoint.getXC();
				panels = (JPanel)chessBoard.getComponent(landingPanelID);
				panels.add(pieces);
				panels.setBorder(redBorder);
				layeredPane.validate();
				layeredPane.repaint();
				/*String tmpString = startingPoint.getName();
				if(startingPoint.getName().contains("Pawn") && landingPoint.getYC()==7){

					// queenAWhitePawn(landingX1, l);
				}*/
			}
			whiteTurn = false;
		}
	}

	// function that handles the movement for the best next move ai agent
	private void makeAIMoveBestNext(){
  /*
    When the AI Agent decides on a move, a red border shows the square from where the move started and the
    landing square of the move.
  */
		resetBorders();
		layeredPane.validate();
		layeredPane.repaint();
		Stack white = findWhitePieces();
		Stack completeMoves = new Stack();
		Move tmp;
		while(!white.empty()){
			Square startingSquare = (Square)white.pop();
			String tmpString = startingSquare.getName();
			Stack<Move> tmpMoves = new Stack();
			Stack temporary = new Stack();
    /*
        We need to identify all the possible moves that can be made by the AI Opponent
    */
			// get the AI to get the moves for the knight
			if(tmpString.contains("Knight")){
				tmpMoves = getKnightMoves(startingSquare.getXC(), startingSquare.getYC(), startingSquare.getName());
			}
			// get the AI to get the moves for the bishop
			else if(tmpString.contains("Bishop")){
				tmpMoves = getBishopMoves(startingSquare.getXC(), startingSquare.getYC(), startingSquare.getName());
			}
			// get the AI to get the moves for the pawn
			else if(tmpString.contains("Pawn")){
				tmpMoves = getWhitePawnMoves(startingSquare.getXC(), startingSquare.getYC(), startingSquare.getName());
			}
			// get the AI to get the moves for the rook
			else if(tmpString.contains("Rook")){
				tmpMoves = getRookMoves(startingSquare.getXC(), startingSquare.getYC(), startingSquare.getName());
			}
			// get the AI to get the moves for the queen
			else if(tmpString.contains("Queen")){
				tmpMoves = getQueenMoves(startingSquare.getXC(), startingSquare.getYC(), startingSquare.getName());
			}
			// get the AI to get the moves for the king
			else if(tmpString.contains("King")){
				tmpMoves = getKingMoves(startingSquare.getXC(), startingSquare.getYC(), startingSquare.getName());
			}

			// tmpMoves is a Stack of Squares
			while(!tmpMoves.empty()){
				completeMoves.push(tmpMoves.pop());
			}
		}
		temporary = (Stack)completeMoves.clone();
		getLandingSquares(temporary);
		printStack(temporary);
/*
So now we should have a copy of all the possible moves to make in our Stack called completeMoves
*/
		if(completeMoves.size() == 0){
/*
    In Chess if you cannot make a valid move but you are not in Check this state is referred to
    as a Stale Mate
*/
			JOptionPane.showMessageDialog(null, "Congratulations, you have placed the AI component in a Stale Mate Position");
			System.exit(0);

		}
		else{
  /*
    Okay, so we can make a move now. We have a stack of all possible moves and need to call the correct agent to select
    one of these moves. Lets print out the possible moves to the standard output to view what the options are for
    White. Later when you are finished the continuous assessment you don't need to have such information being printed
    out to the standard output.
  */
			System.out.println("=============================================================");
			Stack testing = new Stack();
			while(!completeMoves.empty()){
				Move tmpMove = (Move)completeMoves.pop();
				Square s1 = (Square)tmpMove.getStart();
				Square s2 = (Square)tmpMove.getLanding();
				System.out.println("The "+s1.getName()+" can move from ("+s1.getXC()+", "+s1.getYC()+") to the following square: ("+s2.getXC()+", "+s2.getYC()+")");
				testing.push(tmpMove);
			}
			System.out.println("=============================================================");
			// highlight landing square in red to show where the AI piece chose to move to
			Border redBorder = BorderFactory.createLineBorder(Color.RED, 3);
			// AI performs move based on criteria set in AIAgent
			Move selectedMove = aiPlayer.nextBestMove(testing);
			Square startingPoint = selectedMove.getStart();
			Square landingPoint = selectedMove.getLanding();
			int startX1 = (startingPoint.getXC()*75)+20;
			int startY1 = (startingPoint.getYC()*75)+20;
			int landingX1 = (landingPoint.getXC()*75)+20;
			int landingY1 = (landingPoint.getYC()*75)+20;
			System.out.println("-------- Move "+startingPoint.getName()+" ("+startingPoint.getXC()+", "+startingPoint.getYC()+") to ("+landingPoint.getXC()+", "+landingPoint.getYC()+")");

			Component c  = (JLabel)chessBoard.findComponentAt(startX1, startY1);
			Container parent = c.getParent();
			parent.remove(c);
			int panelID = (startingPoint.getYC() * 8)+startingPoint.getXC();
			panels = (JPanel)chessBoard.getComponent(panelID);
			panels.setBorder(redBorder);
			parent.validate();

			Component l = chessBoard.findComponentAt(landingX1, landingY1);
			if(l instanceof JLabel){
				Container parentlanding = l.getParent();
				JLabel awaitingName = (JLabel)l;
				// attempted to fix ai queening by  getting the moving piece and queening it once it lands on the end of the board but only if its the white pawn
				String agentPiece = startingPoint.getName();
				String agentCaptured = awaitingName.getIcon().toString();
				if(agentCaptured.contains("King")){
					agentwins = true;
				}
				/*if(agentPiece.contains("Pawn")){
					if(landingPoint.getYC() == 7){
						queenAWhitePawn(landingX1, c);
					}
				}*/
				parentlanding.remove(l);
				parentlanding.validate();
				pieces = new JLabel( new ImageIcon(startingPoint.getName()+".png") );
				int landingPanelID = (landingPoint.getYC()*8)+landingPoint.getXC();
				panels = (JPanel)chessBoard.getComponent(landingPanelID);
				panels.add(pieces);
				panels.setBorder(redBorder);
				layeredPane.validate();
				layeredPane.repaint();

				if(agentwins){
					JOptionPane.showMessageDialog(null, "The AI Agent has won!");
					System.exit(0);
				}
				// another method of attempting queening
				/*String tmpString = startingPoint.getName();
				if(startingPoint.getName().contains("Pawn") && landingPoint.getYC()==7){
					queenAWhitePawn(landingX1, l);
				}*/
			}
			else{
				pieces = new JLabel( new ImageIcon(startingPoint.getName()+".png") );
				int landingPanelID = (landingPoint.getYC()*8)+landingPoint.getXC();
				panels = (JPanel)chessBoard.getComponent(landingPanelID);
				panels.add(pieces);
				panels.setBorder(redBorder);
				layeredPane.validate();
				layeredPane.repaint();
			}
			whiteTurn = false;
		}
	}

	// unable to complete
	private void makeAIMoveTwoLevels(){
  /*
    When the AI Agent decides on a move, a red border shows the square from where the move started and the
    landing square of the move.
  */
		resetBorders();
		layeredPane.validate();
		layeredPane.repaint();
		Stack white = findWhitePieces();
		Stack black = findBlackPieces();
		Stack completeMoves = new Stack();
		Move tmp;
		while(!white.empty()){
			Square startingSquare = (Square)white.pop();
			Square startingSquareBlack = (Square)black.pop();
			String tmpString = startingSquare.getName();
			String tmpString1 = startingSquareBlack.getName();
			Stack<Move> tmpMoves = new Stack();
			Stack temporary = new Stack();
    /*
        We need to identify all the possible moves that can be made by the AI Opponent
    */
			// get the AI to get the moves for the knight
			if(tmpString.contains("Knight")){
				tmpMoves = getKnightMoves(startingSquare.getXC(), startingSquare.getYC(), startingSquare.getName());
			}
			// get the AI to get the moves for the bishop
			else if(tmpString.contains("Bishop")){
				tmpMoves = getBishopMoves(startingSquare.getXC(), startingSquare.getYC(), startingSquare.getName());
			}
			// get the AI to get the moves for the pawn
			else if(tmpString.contains("Pawn")){
				tmpMoves = getWhitePawnMoves(startingSquare.getXC(), startingSquare.getYC(), startingSquare.getName());
			}
			// get the AI to get the moves for the rook
			else if(tmpString.contains("Rook")){
				tmpMoves = getRookMoves(startingSquare.getXC(), startingSquare.getYC(), startingSquare.getName());
			}
			// get the AI to get the moves for the queen
			else if(tmpString.contains("Queen")){
				tmpMoves = getQueenMoves(startingSquare.getXC(), startingSquare.getYC(), startingSquare.getName());
			}
			// get the AI to get the moves for the king
			else if(tmpString.contains("King")){
				tmpMoves = getKingMoves(startingSquare.getXC(), startingSquare.getYC(), startingSquare.getName());
			}

			// tmpMoves is a Stack of Squares
			while(!tmpMoves.empty()){
				completeMoves.push(tmpMoves.pop());
			}
		}
		temporary = (Stack)completeMoves.clone();
		getLandingSquares(temporary);
		printStack(temporary);
/*
So now we should have a copy of all the possible moves to make in our Stack called completeMoves
*/
		if(completeMoves.size() == 0){
/*
    In Chess if you cannot make a valid move but you are not in Check this state is referred to
    as a Stale Mate
*/
			JOptionPane.showMessageDialog(null, "Congratulations, you have placed the AI component in a Stale Mate Position");
			System.exit(0);

		}
		else{
  /*
    Okay, so we can make a move now. We have a stack of all possible moves and need to call the correct agent to select
    one of these moves. Lets print out the possible moves to the standard output to view what the options are for
    White. Later when you are finished the continuous assessment you don't need to have such information being printed
    out to the standard output.
  */
			System.out.println("=============================================================");
			Stack testing = new Stack();
			while(!completeMoves.empty()){
				Move tmpMove = (Move)completeMoves.pop();
				Square s1 = (Square)tmpMove.getStart();
				Square s2 = (Square)tmpMove.getLanding();
				System.out.println("The "+s1.getName()+" can move from ("+s1.getXC()+", "+s1.getYC()+") to the following square: ("+s2.getXC()+", "+s2.getYC()+")");
				testing.push(tmpMove);
			}
			System.out.println("=============================================================");
			// highlight landing square in red to show where the AI piece chose to move to
			Border redBorder = BorderFactory.createLineBorder(Color.RED, 3);
			// AI performs move based on criteria set in AIAgent
			Move selectedMove = aiPlayer.twoLevelsDeep(testing);
			Square startingPoint = (Square)selectedMove.getStart();
			Square landingPoint = (Square)selectedMove.getLanding();
			int startX1 = (startingPoint.getXC()*75)+20;
			int startY1 = (startingPoint.getYC()*75)+20;
			int landingX1 = (landingPoint.getXC()*75)+20;
			int landingY1 = (landingPoint.getYC()*75)+20;
			System.out.println("-------- Move "+startingPoint.getName()+" ("+startingPoint.getXC()+", "+startingPoint.getYC()+") to ("+landingPoint.getXC()+", "+landingPoint.getYC()+")");

			Component c  = (JLabel)chessBoard.findComponentAt(startX1, startY1);
			Container parent = c.getParent();
			parent.remove(c);
			int panelID = (startingPoint.getYC() * 8)+startingPoint.getXC();
			panels = (JPanel)chessBoard.getComponent(panelID);
			panels.setBorder(redBorder);
			parent.validate();

			Component l = chessBoard.findComponentAt(landingX1, landingY1);
			if(l instanceof JLabel){
				Container parentlanding = l.getParent();
				JLabel awaitingName = (JLabel)l;
				// attempted to fix ai queening by  getting the moving piece and queening it once it lands on the end of the board but only if its the white pawn
				String agentPiece = startingPoint.getName();
				String agentCaptured = awaitingName.getIcon().toString();
				if(agentCaptured.contains("King")){
					agentwins = true;
				}
				if(agentPiece.contains("Pawn")){
					if(landingPoint.getYC() == 7){
						queenAWhitePawn(landingX1, c);
					}
				}
				parentlanding.remove(l);
				parentlanding.validate();
				pieces = new JLabel( new ImageIcon(startingPoint.getName()+".png") );
				int landingPanelID = (landingPoint.getYC()*8)+landingPoint.getXC();
				panels = (JPanel)chessBoard.getComponent(landingPanelID);
				panels.add(pieces);
				panels.setBorder(redBorder);
				layeredPane.validate();
				layeredPane.repaint();

				if(agentwins){
					JOptionPane.showMessageDialog(null, "The AI Agent has won!");
					System.exit(0);
				}
				// another method of attempting queening
				/*String tmpString = startingPoint.getName();
				if(startingPoint.getName().contains("Pawn") && landingPoint.getYC()==7){
					queenAWhitePawn(landingX1, l);
				}*/
			}
			else{
				pieces = new JLabel( new ImageIcon(startingPoint.getName()+".png") );
				int landingPanelID = (landingPoint.getYC()*8)+landingPoint.getXC();
				panels = (JPanel)chessBoard.getComponent(landingPanelID);
				panels.add(pieces);
				panels.setBorder(redBorder);
				layeredPane.validate();
				layeredPane.repaint();
			}
			whiteTurn = false;
		}
	}

	/*
		This method is called when we press the Mouse. So we need to find out what piece we have 
		selected. We may also not have selected a piece!
	*/
    public void mousePressed(MouseEvent e){
        chessPiece = null;
        Component c =  chessBoard.findComponentAt(e.getX(), e.getY());
        if (c instanceof JPanel)
			return;

        Point parentLocation = c.getParent().getLocation();
        xAdjustment = parentLocation.x - e.getX();
        yAdjustment = parentLocation.y - e.getY();
        chessPiece = (JLabel)c;
		initialX = e.getX();
		initialY = e.getY();
		startX = (e.getX()/75);
		startY = (e.getY()/75);
        chessPiece.setLocation(e.getX() + xAdjustment, e.getY() + yAdjustment);
        chessPiece.setSize(chessPiece.getWidth(), chessPiece.getHeight());
        layeredPane.add(chessPiece, JLayeredPane.DRAG_LAYER);
    }

    public void mouseDragged(MouseEvent me) {
        if (chessPiece == null) return;
         chessPiece.setLocation(me.getX() + xAdjustment, me.getY() + yAdjustment);
     }

 	/*
		This method is used when the Mouse is released...we need to make sure the move was valid before
		putting the piece back on the board.
	*/
    public void mouseReleased(MouseEvent e) {
        if(chessPiece == null) return;

        chessPiece.setVisible(false);
        // variables for queening
		Boolean successWhite = false;
		Boolean successBlack = false;
		// find what piece is at the coordinates
        Component c =  chessBoard.findComponentAt(e.getX(), e.getY());
		String tmp = chessPiece.getIcon().toString();
		String pieceName = tmp.substring(0, (tmp.length()-4));
		Boolean validMove = false;
		// variables for the end of piece movement
		int landingX = e.getX()/75;
		int landingY = e.getY()/75;
		// variables for the movement action
		int movementX = Math.abs(e.getX()/75-startX);
		int movementY = Math.abs(e.getY()/75-startY);

		Boolean possible = false;

		if(!whiteTurn){
			if(pieceName.contains("White")){
				possible = false;
			}
			else if(pieceName.contains("Black")){
					possible = true;
			}
		}


		if(possible){

			// WHITE PAWN
			//
			if(pieceName.equals("WhitePawn")){
				// if at pawn's starting Y position
				if(startY == 1)
				{
					// if moving from pawn's beginning position either 1 OR 2 squares forward
					if(startX == landingX && (movementY==1)||(movementY==2))
					{
						// if moving two squares forward
						if(movementY==2){
							// if there is not a piece present at the landing point after moving one square forward it is a valid move
							if((!piecePresent(e.getX(), (e.getY())))&&(!piecePresent(e.getX(), (e.getY()+75)))){
								validMove = true;
							}
							// else it is not a valid move
							else{
								validMove = false;
							}
						}
						// else you are moving one square forward
						else{
							// if there is not a piece present, it is a valid move
							if((!piecePresent(e.getX(), (e.getY()))))
							{
								validMove = true;
							}
							// else if there is a piece present, it is not a valid move
							else{
								validMove = false;
							}
						}
					}
					// if you are moving more than one or two squares, it is not a valid move
					else{
						validMove = false;
					}
				}
				// if the pawn is not at the initial position
				else{
					// if the pawn is within the board boundaries
					if((startX-1 >=0)||(startX +1 <=7)) {
						// if there is a piece present at the landing square
						if(piecePresent(e.getX(), (e.getY())) && (((landingX == (startX+1) && (startX+1<=7)) || (landingX == (startX-1) && (startX-1 >=0)))))
						{
							// check if the piece present is white's opponent
							if(checkWhiteOpponent(e.getX(), e.getY())){
								// if it is white's opponent, the pawn can capture
								validMove = true;
								// if the pawn reaches the end of the board, it is queened
								if(landingY == 6){
									successWhite = true;
								}
							}
							// it is not white's opponent || it is a white piece
							else{
								validMove = false;
							}
						}
						// there is not a piece present
						else{
							// if there is not a piece present at location
							if(!piecePresent(e.getX(), (e.getY()))){
								// if the piece is moving forward one // is moving down the board one
								if((startX == (landingX))&&((landingY)-startY)==1){
									// if the pawn reaches the opposite end of the board
									if(landingY == 6){
										// the pawn is queened (using queening function)
										successWhite = true;
									}
									// the move is valid
									validMove = true;
								}
								// the pawn is trying to move more than one square forward
								else{
									validMove = false;
								}
							}
							// there is a piece present
							else{
								validMove = false;
							}
						}
					}
					// the pawn is trying to move off the board
					else{
						validMove = false;
					}
				}
			}
			else if(pieceName.equals("BlackPawn")){
				// if at pawn's starting Y position
				if(startY == 6)
				{
					// if moving from pawn's beginning position either 1 OR 2 squares forward
					if(startX == landingX && (movementY==1)||(movementY==2))
					{
						// if moving two squares forward
						if(movementY==2){
							// if there is not a piece present at the landing point after moving one square forward it is a valid move
							if((!piecePresent(e.getX(), (e.getY())))&&(!piecePresent(e.getX(), (e.getY()+75)))){
								validMove = true;
							}
							// else it is not a valid move
							else{
								validMove = false;
							}
						}
						// else you are moving one square forward
						else{
							// if there is not a piece present, it is a valid move
							if((!piecePresent(e.getX(), (e.getY()))))
							{
								validMove = true;
							}
							// else if there is a piece present, it is not a valid move
							else{
								validMove = false;
							}
						}
					}
					// if you are moving more than one or two squares, it is not a valid move
					else{
						validMove = false;
					}
				}
				else{
					// if within board boundaries
					if((startX+1 >=0)||(startX -1 <=7))
					{
						// if there is a piece present at the landing spot
						if((piecePresent(e.getX(), (e.getY())))&&((((landingX == (startX-1)&&(startX-1>=0)))||((landingX == (startX+1))&&(startX+1 <=7)))))
						{
							// check if the piece is an opponent
							if(checkBlackOpponent(e.getX(), e.getY())){
								validMove = true;
								// if the pawn has landed on the last square at the opposite end of the board
								if(startY == 1){
									// it is queened
									successBlack = true;
								}
							}
							// illegal move
							else{
								validMove = false;
							}
						}
						// there is no piece present
						else{
							// if there isnt a piece present at the landing spot
							if(!piecePresent(e.getX(), (e.getY()))){
								// if moving up the board
								if((startX == (landingX))&&((landingY)-startY)==-1){
									// if it has reached the end of the board
									if(startY == 1){
										// it is queened
										successBlack = true;
									}
									validMove = true;
								}
								else{
									validMove = false;
								}
							}
							else{
								validMove = false;
							}
						}
					}
					else{
						validMove = false;
					}
				}
			}

		/*
		KNIGHT MOVEMENT
		Knights should be able to move omni directionally , so long as they move in an L shape
		 */


			else if(pieceName.contains("Knight")){
				// ensure that the piece cannot fall off the board
				if(((landingX < 0) || (landingY > 7) || ((landingY < 0) || (landingX > 7)))){
					validMove = false;
				}
				else{
					// allow the knight to only move in an "L" shape
					if(((landingX == startX+1) && (landingY == startY+2)) || ((landingX == startX-1) && (landingY == startY+2)) || ((landingX == startX+1) && (landingY == startY-2)) || ((landingX == startX-1) && (landingY == startY-2)) || ((landingX == startX+2) && (landingY == startY+1)) || ((landingX == startX-2) && (landingY == startY+1)) || ((landingX == startX+2) && (landingY == startY-1)) || ((landingX == startX-2) && (landingY == startY-1))){
						// if there is no piece present on the landing square, the piece can move
						if(!piecePresent(e.getX(), e.getY())){
							validMove = true;
						}
						// there is a piece present
						else{
							// check if the piece on the landing square is a white piece
							if(pieceName.contains("White")){
								// if it is an opponent's piece, take it
								if(checkWhiteOpponent(e.getX(), e.getY())){
									validMove = true;
								}
							}
							// check if the piece on the landing square is a black a black piece
							else{
								// if it is an opponent's piece, takie it
								if(checkBlackOpponent(e.getX(), e.getY())){
									validMove = true;
								}
							}
						}
					}
					// illegal move
					else{
						validMove = false;
					}
				}
			}

			else if(pieceName.contains("Bishop")){
				// used for checking if there is a piece blocking movement to landing coordinates
				Boolean inTheWay = false;
				// how far the piece it moving
				int distance = Math.abs(startX-landingX);
				// ensure the piece cant fall off the board
				if(((landingX < 0) || (landingX > 7) || (landingY < 0) || (landingY >7))){
					validMove = false;
				}
				else if(landingX == startX && landingY == startY){
					validMove = false;
				}
				else{
					validMove = true;
					// if the piece is moving diagonally
					if(Math.abs(startX-landingX)==Math.abs(startY-landingY)){
						// if the piece is moving diagonally to the South West (-,-)
						if((startX-landingX < 0) && (startY-landingY < 0)){
							// loop through every square along movement to check if there is anything blocking the piece's path
							for(int i=0; i < distance; i++){
								// if a piece is found along the way before reaching the landing Co-ordinates, it is in the way and is not allowed
								if(piecePresent((initialX+(i*75)), (initialY+(i*75)))){
									// there is a piece blocking movement
									inTheWay = true;
								}
							}
						}
						// if the piece is moving diagonally to the North West (-,+)
						else if((startX-landingX < 0) && (startY-landingY > 0)){
							// loop through every square along movement to check if there is anything blocking the piece's path
							for(int i=0; i < distance;i++){
								// if a piece is found along the way before reaching the landing Co-ordinates, it is in the way and is not allowed
								if(piecePresent((initialX+(i*75)), (initialY-(i*75)))){
									// there is a piece blocking movement
									inTheWay = true;
								}
							}
						}
						// if the piece is moving diagonally to the North East (+,+)
						else if((startX-landingX > 0) && (startY-landingY > 0)){
							// loop through every square along movement to check if there is anything blocking the piece's path
							for(int i=0; i < distance;i++){
								// if a piece is found along the way before reaching the landing Co-ordinates, it is in the way and is not allowed
								if(piecePresent((initialX-(i*75)), (initialY-(i*75)))){
									// there is a piece blocking movement
									inTheWay = true;
								}
							}
						}
						// if the piece is moving diagonally to the South East (+,-)
						else if((startX-landingX > 0) && (startY-landingY < 0)){
							// loop through every square along movement to check if there is anything blocking the piece's path
							for(int i=0; i < distance;i++){
								// if a piece is found along the way before reaching the landing Co-ordinates, it is in the way and is not allowed
								if(piecePresent((initialX-(i*75)), (initialY+(i*75)))){
									// there is a piece blocking movement
									inTheWay = true;
								}
							}
						}

						// if there is something in the way, the move is not allowed
						if(inTheWay){
							validMove = false;
						}
						else{
							// if there is a piece present
							if(piecePresent(e.getX(), (e.getY()))){
								// if the piece present is white
								if(pieceName.contains("White")){
									// check if the piece is black's opponent
									if(checkWhiteOpponent(e.getX(), e.getY())){
										validMove = true;
									}
									// the piece is black's own piece
									else{
										validMove = false;
									}
								}
								// if the piece present is black
								else{
									// check if the piece is white's opponent
									if(checkBlackOpponent(e.getX(), e.getY())){
										validMove = true;
									}
									// the piece is white's own piece
									else{
										validMove = false;
									}
								}
							}
							else{
								validMove = true;
							}
						}
					}
					else{
						validMove = false;
					}
				}
			}

			else if(pieceName.contains("Rook")){
				// used for checking if there is a piece blocking the path to the landing point
				Boolean inTheWay = false;
				// ensure that the piece cannot move off the board
				if(((landingX < 0) || (landingX > 7) || (landingY < 0) || (landingY > 7))){
					validMove = false;
				}
				else{
					// if you are moving on the X axis || on the Y axis (X movement does not equal 0 AND the Y move does equal 0 || vice versa)
					if(((Math.abs(startX-landingX)!=0) && (Math.abs(startY-landingY)==0)) || ((Math.abs(startX-landingX)==0) && (Math.abs(landingY-startY)!=0))){
						// if you are moving on the X axis
						if(Math.abs(startX-landingX)!=0){
							// setting value of how far the movement is
							int xMovement = Math.abs(startX-landingX);
							// if you are moving to the right
							if(startX-landingX > 0){
								// loop through every square along movement to check if there is anything blocking the piece's path
								for(int i=0; i< xMovement; i++){
									// if a piece is found along the way before reaching the landing Co-ordinates, it is in the way and is not allowed
									if(piecePresent(initialX-(i*75), e.getY())){
										inTheWay = true;
										break;
									}
									// there is nothing in the way and movement is allowed
									else{
										inTheWay = false;
									}
								}
							}
							// you are moving to the left
							else{
								// loop through every square along movement to check if there is anything blocking the piece's path
								for(int i=0; i < xMovement; i++){
									// if a piece is found along the way before reaching the landing Co-ordinates, it is in the way and is not allowed
									if(piecePresent(initialX+(i*75), e.getY())){
										inTheWay = true;
										break;
									}
									// there is nothing in the way and movement is allowed
									else{
										inTheWay = false;
									}
								}
							}
						}
						// you are moving on the Y axis
						else{
							// setting the value of how far the movement is
							int yMovement = Math.abs(startY-landingY);
							// if you are moving down the board
							if(startY-landingY > 0){
								// loop through every square along movement to check if there is anything blocking the piece's path
								for(int i=0; i < yMovement;i++){
									// if a piece is found along the way before reaching the landing Co-ordinates, it is in the way and is not allowed
									if(piecePresent(e.getX(), initialY-(i*75))){
										inTheWay = true;
										break;
									}
									// there is nothing in the way and movement is allowed
									else{
										inTheWay = false;
									}
								}
							}
							// you are moving up the board
							else{
								// loop through every square along movement to check if there is anything blocking the piece's path
								for(int i=0; i < yMovement; i++){
									// if a piece is found along the way before reaching the landing Co-ordinates, it is in the way and is not allowed
									if(piecePresent(e.getX(), initialY+(i*75))){
										inTheWay = true;
										break;
									}
									// there is nothing in the way and movement is allowed
									else{
										inTheWay = false;
									}
								}
							}
						}

						// if there is something in the way, the move is not allowed
						if(inTheWay){
							validMove = false;
						}
						else{
							// if there is a piece present
							if(piecePresent(e.getX(), e.getY())){
								// if the piece present is white
								if(pieceName.contains("White")){
									// check if the piece is black's opponent
									if(checkWhiteOpponent(e.getX(), e.getY())){
										validMove = true;
									}
									// the piece is black's own piece
									else{
										validMove = false;
									}
								}
								// if the piece present is black
								else{
									// check if the piece is white's opponent
									if(checkBlackOpponent(e.getX(), e.getY())){
										validMove = true;
									}
									// the piece is black's own piece
									else{
										validMove = false;
									}
								}
							}
							else{
								validMove = true;
							}
						}
					}
					else{
						validMove = false;
					}
				}
			}

			else if(pieceName.contains("Queen")){
				// used for checking if there is a piece blocking movement
				Boolean inTheWay = false;
				// used when determining how far the piece is moving/has moved
				int distance = Math.abs(startX-landingX);
				// keep it on the board
				if(((landingX < 0) || (landingX > 7) || (landingY < 0) || (landingY > 7))){
					validMove = false;
				}
				// stop the piece from accepting no movement as a turn
				else if(landingX == startX && landingY == startY){
					validMove = false;
				}
				else if(Math.abs(startX-landingX)==Math.abs(startY-landingY)){
					// if the piece is moving diagonally to the South West (-,-)
					if((startX-landingX < 0) && (startY-landingY < 0)){
						// loop through every square along movement to check if there is anything blocking the piece's path
						for(int i=0; i < distance; i++){
							// if a piece is found along the way before reaching the landing Co-ordinates, it is in the way and is not allowed
							if(piecePresent((initialX+(i*75)), (initialY+(i*75)))){
								// there is a piece blocking movement
								inTheWay = true;
							}
						}
					}
					// if the piece is moving diagonally to the North West (-,+)
					else if((startX-landingX < 0) && (startY-landingY > 0)){
						// loop through every square along movement to check if there is anything blocking the piece's path
						for(int i=0; i < distance;i++){
							// if a piece is found along the way before reaching the landing Co-ordinates, it is in the way and is not allowed
							if(piecePresent((initialX+(i*75)), (initialY-(i*75)))){
								// there is a piece blocking movement
								inTheWay = true;
							}
						}
					}
					// if the piece is moving diagonally to the North East (+,+)
					else if((startX-landingX > 0) && (startY-landingY > 0)){
						// loop through every square along movement to check if there is anything blocking the piece's path
						for(int i=0; i < distance;i++){
							// if a piece is found along the way before reaching the landing Co-ordinates, it is in the way and is not allowed
							if(piecePresent((initialX-(i*75)), (initialY-(i*75)))){
								// there is a piece blocking movement
								inTheWay = true;
							}
						}
					}
					// if the piece is moving diagonally to the South East (+,-)
					else if((startX-landingX > 0) && (startY-landingY < 0)){
						// loop through every square along movement to check if there is anything blocking the piece's path
						for(int i=0; i < distance;i++){
							// if a piece is found along the way before reaching the landing Co-ordinates, it is in the way and is not allowed
							if(piecePresent((initialX-(i*75)), (initialY+(i*75)))){
								// there is a piece blocking movement
								inTheWay = true;
							}
						}
					}

					// if there is something in the way, the move is not allowed
					if(inTheWay){
						validMove = false;
					}
					else{
						// if there is a piece present
						if(piecePresent(e.getX(), (e.getY()))){
							// if the piece present is white
							if(pieceName.contains("White")){
								// check if the piece is black's opponent
								if(checkWhiteOpponent(e.getX(), e.getY())){
									validMove = true;
								}
								// the piece is black's own piece
								else{
									validMove = false;
								}
							}
							// if the piece present is black
							else{
								// check if the piece is white's opponent
								if(checkBlackOpponent(e.getX(), e.getY())){
									validMove = true;
								}
								// the piece is white's own piece
								else{
									validMove = false;
								}
							}
						}
						else{
							validMove = true;
						}
					}
				}
				// you are moving horizontally or vertically
				else if(((Math.abs(startX-landingX)!=0) && (Math.abs(startY-landingY)==0)) || ((Math.abs(startX-landingX)==0) && (Math.abs(landingY-startY)!=0))){
					// if you are moving on the X axis
					if(Math.abs(startX-landingX)!=0){
						// setting value of how far the movement is
						int xMovement = Math.abs(startX-landingX);
						// if you are moving to the right
						if(startX-landingX > 0){
							// loop through every square along movement to check if there is anything blocking the piece's path
							for(int i=0; i< xMovement; i++){
								// if a piece is found along the way before reaching the landing Co-ordinates, it is in the way and is not allowed
								if(piecePresent(initialX-(i*75), e.getY())){
									inTheWay = true;
									break;
								}
								// there is nothing in the way and movement is allowed
								else{
									inTheWay = false;
								}
							}
						}
						// you are moving to the left
						else{
							// loop through every square along movement to check if there is anything blocking the piece's path
							for(int i=0; i < xMovement; i++){
								// if a piece is found along the way before reaching the landing Co-ordinates, it is in the way and is not allowed
								if(piecePresent(initialX+(i*75), e.getY())){
									inTheWay = true;
									break;
								}
								// there is nothing in the way and movement is allowed
								else{
									inTheWay = false;
								}
							}
						}
					}
					// you are moving on the Y axis
					else{
						// setting the value of how far the movement is
						int yMovement = Math.abs(startY-landingY);
						// if you are moving down the board
						if(startY-landingY > 0){
							// loop through every square along movement to check if there is anything blocking the piece's path
							for(int i=0; i < yMovement;i++){
								// if a piece is found along the way before reaching the landing Co-ordinates, it is in the way and is not allowed
								if(piecePresent(e.getX(), initialY-(i*75))){
									inTheWay = true;
									break;
								}
								// there is nothing in the way and movement is allowed
								else{
									inTheWay = false;
								}
							}
						}
						// you are moving up the board
						else{
							// loop through every square along movement to check if there is anything blocking the piece's path
							for(int i=0; i < yMovement; i++){
								// if a piece is found along the way before reaching the landing Co-ordinates, it is in the way and is not allowed
								if(piecePresent(e.getX(), initialY+(i*75))){
									inTheWay = true;
									break;
								}
								// there is nothing in the way and movement is allowed
								else{
									inTheWay = false;
								}
							}
						}
					}

					// if there is something in the way, the move is not allowed
					if(inTheWay){
						validMove = false;
					}
					else{
						// if there is a piece present
						if(piecePresent(e.getX(), e.getY())){
							// if the piece present is white
							if(pieceName.contains("White")){
								// check if the piece is black's opponent
								if(checkWhiteOpponent(e.getX(), e.getY())){
									validMove = true;
								}
								// the piece is black's own piece
								else{
									validMove = false;
								}
							}
							// if the piece present is black
							else{
								// check if the piece is white's opponent
								if(checkBlackOpponent(e.getX(), e.getY())){
									validMove = true;
								}
								// the piece is black's own piece
								else{
									validMove = false;
								}
							}
						}
						else{
							validMove = true;
						}
					}
				}
				else{
					validMove = false;
				}
			}

			else if(pieceName.contains("King")){
				// ensure the piece cannot fall off the board
				if(((landingX < 0) || (landingX > 7) || (landingY < 0) || (landingY > 7))){
					validMove = false;
				}
				else{
					// restrict the movement to only 1 square moving omnidirectionally
					if((movementX ==1)||(movementX ==-1)||(movementY ==1)||(movementY ==-1)||((movementX ==1) && (movementY ==1))||((movementX ==-1) && (movementY ==1))||((movementX ==-1) && (movementY ==-1))||((movementX ==1) && (movementY ==-1))){
						// if there is no piece at landing square, legal move
						if(!piecePresent(e.getX(), e.getY())){
							// check if moving into check space
							validMove = true;
						}
						else{
							// if there is a piece present
							if(piecePresent(e.getX(), (e.getY()))){
								// if the piece present is a white piece
								if(pieceName.contains("White")){
									// check if the piece is an opponent
									if(checkWhiteOpponent(e.getX(), e.getY())){
										validMove = true;
									}
									else{
										validMove = false;
									}
								}
								else{
									// check if the piece is the opponent for the other player
									if(checkBlackOpponent(e.getX(), e.getY())){
										validMove = true;
									}
									else{
										validMove = false;
									}
								}
							}
							else{
								validMove = true;
							}
						}
					}
					else{
						validMove = false;
					}
				}
			}
		}

		// if the move made is not valid, reset the piece to its initial location
		if(!validMove){
			int location=0;
			if(startY ==0){
				location = startX;
			}
			else{
				location  = (startY*8)+startX;
			}
			String pieceLocation = pieceName+".png";
			pieces = new JLabel( new ImageIcon(pieceLocation) );
			panels = (JPanel)chessBoard.getComponent(location);
		    panels.add(pieces);
		}
		// if it is a valid move
		else{
			// if the piece is a white pawn, it is queened
			if(successWhite){
				queenAWhitePawn(landingX,c);
			}
			// if the piece is a black pawn, it is queened
			else if(successBlack){
				queenABlackPawn(landingX,c);
            }
			else{
				if (c instanceof JLabel){
	            	Container parent = c.getParent();
	            	parent.remove(0);
	            	parent.add( chessPiece );
	        	}
	        	else {
	            	Container parent = (Container)c;
	            	parent.add( chessPiece );
	        	}
	    		chessPiece.setVisible(true);
			}
			// Tell the Ai to play using random moves AI
			if(AIDifficulty == 0) {
				makeAIMoveRandom();
			}
			// tell the AI to play using next best move AI
			else if(AIDifficulty == 1) {
				makeAIMoveBestNext();
			}
		}
    }
 
    public void mouseClicked(MouseEvent e) {
	
    }
    public void mouseMoved(MouseEvent e) {
   }
    public void mouseEntered(MouseEvent e){
	
    }
    public void mouseExited(MouseEvent e) {

    }

    // white queening function
    public void queenAWhitePawn(int landingX, Component c){
    	// this finds where the pawn is landing
		int location = 56 + landingX;
		Container parent;
		// this removes the pawn from the board
		if (c instanceof JLabel){
			parent = c.getParent();
			parent.remove(0);
		}
		// then replace it with a Queen instead where it landed
		pieces = new JLabel( new ImageIcon("WhiteQueen.png") );
		parent = (JPanel)chessBoard.getComponent(location);
		parent.add(pieces);
	}

	// black queening function
	public void queenABlackPawn(int landingX, Component c){
		// this finds where the pawn is landing
		int location = landingX;
		Container parent;
		// this removes the pawn from the board
		if (c instanceof JLabel){
			parent = c.getParent();
			parent.remove(0);
		}
		// then replace it with a Queen instead where it landed
		pieces = new JLabel( new ImageIcon("BlackQueen.png") );
		parent = (JPanel)chessBoard.getComponent(location);
		parent.add(pieces);
	}
 	
	/*
		Main method that gets the ball moving.
	*/
    public static void main(String[] args) {
        ChessProject frame = new ChessProject();
        frame.setDefaultCloseOperation(DISPOSE_ON_CLOSE );
        frame.pack();
        frame.setResizable(true);
        frame.setLocationRelativeTo( null );
        frame.setVisible(true);
        // difficulty screen
		Object[] options = {"Random Moves","Best Next Move","Based on Opponents Moves"};
		AIDifficulty = JOptionPane.showOptionDialog(frame,"Choose AI Behaviour","Introduction to AI Chess Project", JOptionPane.YES_NO_CANCEL_OPTION, JOptionPane.QUESTION_MESSAGE,null,options,options[2]);
		// to set difficulty, when the player chooses an option, that option has a set value of either 0,1 or 2
		// 0 being the random AI, 1 being the nextBestMove AI, and 2 being the Based on opponents moves ai
		// this is how the program knows to use the random ai
		if(AIDifficulty==0){
			System.out.println("Difficulty level : Random Moves");
			frame.makeAIMoveRandom();
		}
		// this is how the program knows to use the greedy best ai
		else if(AIDifficulty==1){
			System.out.println("Difficulty level : Best Next Move");
			frame.makeAIMoveBestNext();
		}
		else{
			System.out.println("Difficulty level : Based on Opponents Moves");
			frame.makeAIMoveTwoLevels();
		}
		//System.out.println("Difficulty level : "+n);
		//frame.makeAIMove();
    }
}


