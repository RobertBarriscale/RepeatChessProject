class Move{
    // used for dealing with the start square before the piece has moved
    Square start;
    // used for dealing with the landing square after the piece has moved
    Square landing;
    // always have minimum value of 0
    int score = 0;

    /*
        if you extend the class Move to include an evaluation of the move ... the output of the
        utility function you wont need to create an additional data structure for keeping track of the scores
        for each of the movements.
     */

    // a move needs a starting square and a landing square to function
    public Move(Square x, Square y){
        start = x;
        landing = y;
    }

    public Move(){

    }

    // get the starting and landing squares of the move
    public Square getStart(){
        return start;
    }

    public Square getLanding(){
        return landing;
    }
}