class Square{
    // declare the coordinates of the square and the piece on it
    public int xCoor;
    public int yCoor;
    public String pieceName;

    // a square requires an x coordinate and a y coordinate. if there is a piece on it, it needs to know what piece
    public Square(int x, int y, String name){
        xCoor = x;
        yCoor = y;
        pieceName = name;
    }

    public Square(int x, int y){
        xCoor = x;
        yCoor = y;
        pieceName = "";
    }

    // get the x coordinate of the square
    public int getXC(){
        return xCoor;
    }

    // get the y coordinate of the square
    public int getYC(){
        return yCoor;
    }

    // get the name of the piece on the square
    public String getName(){
        return pieceName;
    }
}