/* import java.util.Stack;

public class Knight {
    //transcribe getKnightMoves method
    public void getKnightMoves(int x, int y, String piece){
        Stack moves = new Stack();
        Stack attacking = new Stack();

        Square s = new Square(x+1, y+2);
        moves.push(s);
        Square s1 = new Square(x+1, y+2);
        moves.push(s1);
        Square s2 = new Square(x-1, y+2);
        moves.push(s2);
        Square s3 = new Square(x-1, y+2);
        moves.push(s3);
        Square s4 = new Square(x+2, y+1);
        moves.push(s4);
        Square s5 = new Square(x+2, y-1);
        moves.push(s5);
        Square s6 = new Square(x-2, y+1);
        moves.push(s6);
        Square s7 = new Square(x-2, y-1);
        moves.push(s7);
        for(int i=0; i < 8; i++){
            Square tmp =(Square)moves.pop();
            if((tmp.getXC() < 0) || (tmp.getXC() > 7) || (tmp.getYC() < 0) || (tmp.getYC() >7)){
                break;
            }
            else if(piecePresent(((tmp.getXC()*75)+20), (((tmp.getYC()*75)+20)))){
                if(pieceName.contains("White")){
                    if(checkWhiteOpponent(((tmp.getXC()*75)+20), (((tmp.getYC()*75)+20)))){
                        attacking.push(tmp);
                    }
                    else{
                        System.out.println("It's white's own piece");
                    }
                }
                else{
                    if(checkBlackOpponent(tmp.getXC(), tmp.getYC())){
                        attacking.push(tmp);
                    }
                }
            }
            else{
                attacking.push(tmp);
            }
        }
        Stack tmp = attacking;
        return attacking;
    }
}
*/